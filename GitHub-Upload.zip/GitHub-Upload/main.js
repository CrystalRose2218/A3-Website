/* ###### A3 JS File ######## */

/* ====== Website Navigation ================================================== */

/* Using display: block/ none to create appearance of multiple pages */
const landingPage = document.getElementById('landing-page')
const mainPage = document.getElementById('main-page')
const recipeSection = document.querySelector('.glider-contain')


let startButton = document.querySelector('.start-button')
startButton.addEventListener('click', () => {
    landingPage.style.display = "none"
    mainPage.style.display = "block"
    recipeSection.style.display = "none"
    recipeSection.style.display = "block"
})

/* ======= Landing Page mouse effect ================================ */

landingPage.addEventListener('mousemove', parallax);

function parallax(e) {
    document.querySelectorAll('.image-overlay').forEach(function(move) {
        let moving = move.getAttribute('data-value');
        let x = (e.clientX * moving) / 200;
        let y = (e.clientY * moving) / 200;

        move.style.transform = "translateX(" + x + "px) translateY(" + y + "px)";
    });
}
/*
landingPage.addEventListener('mousemove', (e) => {
    document.querySelectorAll('.image-overlay').forEach((move) => {
        let moving = move.getAttribute('data-set')
        let x = (e.clientX * moving) / 100
        let y = (e.clientY * moving) / 100

        move.style.transform = "translate(${x}px, ${y}px)"

    })
})


/* ====== Checkbox Functionality ================================================== */

/* Scroll Interactions ================================== 
const timeline = gsap.timeline({
    defaults: {
        ease: 'power4.inOut',
    }
})
gsap
    .timeline({
        scrollTrigger:{
            trigger: "",
            scrub: .01,
        },
    })
    .from('.skill-left .text-content', {
        x: 300,
    })
    .to ('.skill-left .text-content')

gsap.to(".rice-text", {
    scrollTrigger: ".rice .skill-checkbox", // start the animation when ".box" enters the viewport (once)
    y: 200,
});


/* Storing checkbox elements as variables */
let allSkills = document.querySelectorAll('.skill .skill-checkbox')

const riceCheckbox = document.querySelector('.rice .skill-checkbox')
const onionCheckbox = document.querySelector('.onion .skill-checkbox')
const herbCheckbox = document.querySelector('.herb .skill-checkbox')
const eggCheckbox = document.querySelector('.egg .skill-checkbox')
const vegCheckbox = document.querySelector('.veggie .skill-checkbox')
const pastaCheckbox = document.querySelector('.pasta .skill-checkbox')
const meatCheckbox = document.querySelector('.meat .skill-checkbox')
const fruitCheckbox = document.querySelector('.fruit .skill-checkbox')

/* Declaring variables to track whether skills have been checked */
let riceSkill = false;
let onionSkill = false;
let herbSkill = false;
let eggSkill = false;
let veggieSkill = false;
let pastaSkill = false;
let meatSkill = false;
let fruitSkill = false;

/* Creating Event Listeners for each checkbox - MY attempt at creating a more modular version
allSkills.forEach(function(skill) {
    console.log(skill)
    console.log(skill.parentElement.classList[2] + ": " + skill.checked)
    let skillName = skill.parentElement.classList[2]
    skill.addEventListener('click', () => {
        mySkills[skillName] = skill.checked
        
    })

}) */

/* Changing the recipe skill list based on checklist input

| These event listeners will update the boolean variables for each skill declared above 
| then if that skill is true, it adds CSS class name to add a green tick to each recipe card with that skill requirement
| OR it takes it off if the skill is now false */

riceCheckbox.addEventListener('sl-change', () => {
    riceSkill = riceCheckbox.checked
    updateSkills()
    let riceCheck = document.querySelectorAll('.rice-check') /* Selecting list item for 'Cook Rice' */
    if (riceSkill == true) {
        for (let i = 0; i < riceCheck.length; i++) {
            riceCheck[i].classList.add('checked')
        }
    }
    else {
        for (let i = 0; i < riceCheck.length; i++) {
            riceCheck[i].classList.remove('checked')
        }
    }
})

onionCheckbox.addEventListener('sl-change', () => {
    onionSkill = onionCheckbox.checked
    updateSkills()
    let onionCheck = document.querySelectorAll('.onion-check') /* Selecting list item for 'Chop Onions' */
    if (onionSkill == true) {
        for (let i = 0; i < onionCheck.length; i++) {
            onionCheck[i].classList.add('checked')
        }
    }
    else {
        for (let i = 0; i < onionCheck.length; i++) {
            onionCheck[i].classList.remove('checked')
        }
    }
})

herbCheckbox.addEventListener('sl-change', () => {
    herbSkill = herbCheckbox.checked
    updateSkills()
    let herbCheck = document.querySelectorAll('.herb-check') /* Selecting list item for 'Chop Herbs' */
    if (herbSkill == true) {
        for (let i = 0; i < herbCheck.length; i++) {
            herbCheck[i].classList.add('checked')
        }
    }
    else { 
        for (let i = 0; i < herbCheck.length; i++) {
            herbCheck[i].classList.remove('checked')
        }
    }
})

eggCheckbox.addEventListener('sl-change', () => {
    eggSkill = eggCheckbox.checked
    updateSkills()
    let eggCheck = document.querySelectorAll('.egg-check') /* Selecting list item for 'Boil Eggs' */
    if (eggSkill == true) {
        for (let i = 0; i < eggCheck.length; i++) {
            eggCheck[i].classList.add('checked')
        }
    }
    else { 
        for (let i = 0; i < eggCheck.length; i++) {
            eggCheck[i].classList.remove('checked')
        }
    }
})

vegCheckbox.addEventListener('sl-change', () => {
    veggieSkill = vegCheckbox.checked
    updateSkills()
    let vegCheck = document.querySelectorAll('.veg-check') /* Selecting list item for 'Roast Vegs' */
    if (veggieSkill == true) {
        for (let i = 0; i < vegCheck.length; i++) {
            vegCheck[i].classList.add('checked')
        }
    }
    else { 
        for (let i = 0; i < vegCheck.length; i++) {
            vegCheck[i].classList.remove('checked')
        }
    }
})

/* Pasta Checklist - Update to Recipe Visuals */
pastaCheckbox.addEventListener('sl-change', () => {
    pastaSkill = pastaCheckbox.checked
    updateSkills()
    let pastaCheck = document.querySelectorAll('.pasta-check') /* Selecting skills for 'Cook Pasta' */
    if (pastaSkill == true) {
        for (let i = 0; i < pastaCheck.length; i++) {
            pastaCheck[i].classList.add('checked')
        }
    }
    else {
        for (let i = 0; i < pastaCheck.length; i++) {
            pastaCheck[i].classList.remove('checked')
        }
    }
})

meatCheckbox.addEventListener('sl-change', () => {
    meatSkill = meatCheckbox.checked
    updateSkills()
    let meatCheck = document.querySelectorAll('.meat-check') /* Selecting skills for 'Marinade meat' */
    if (meatSkill == true) {
        for (let i = 0; i < meatCheck.length; i++) {
            meatCheck[i].classList.add('checked')
        }
    }
    else {
        for (let i = 0; i < meatCheck.length; i++) {
            meatCheck[i].classList.remove('checked')
        }
    }
})

fruitCheckbox.addEventListener('sl-change', () => {
    fruitSkill = fruitCheckbox.checked
    updateSkills()
    let fruitCheck = document.querySelectorAll('.fruit-check') /* Selecting skills for 'Chop fruit' */
    if (fruitSkill == true) {
        for (let i = 0; i < fruitCheck.length; i++) {
            fruitCheck[i].classList.add('checked')
        }
    }
    else {
        for (let i = 0; i < fruitCheck.length; i++) {
            fruitCheck[i].classList.remove('checked')
        }
    }
})

/* ====== Image Carousel Functionality ================================================== */

/* Recipe Carousel uses the library Glider.js */
new Glider(document.querySelector('.glider'), {
    slidesToShow: 1,
    slidesToScroll: 1,
    draggable: false,
    arrows: {
        prev: '.glider-prev',
        next: '.glider-next'
    },

    /* Responsive change to one recipe card per view for mobile */
    responsive: [
        {
            breakpoint: 800,
            settings: {
                slidesToShow: '3',
                slidesToScroll: '1'
            }
        }
    ] 
});

/* ====== Changing the Recipe Card appearance =========== */

/* Creating an object for each recipe */
let spagSkillList = {
    pasta: false,
    veg: false,
    herbs: false
}

/* storing skill set divs for each recipe */
let pastaCheck = document.querySelector('.pasta-check')


/* -- My Functions -- */
function updateSkills() {
    console.log('Rice: ' + riceSkill +'\nOnion: ' + onionSkill + '\nHerb: ' + herbSkill + 
                '\nEgg: ' + eggSkill + '\nVeg: ' + veggieSkill + '\nPasta: ' + pastaSkill +
                '\nMeat: ' + meatSkill + '\nFruit: ' +fruitSkill)
}